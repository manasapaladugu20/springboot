package com.ecommerce.Controller;

import com.ecommerce.Exception.CustomerNotFoundException;
import com.ecommerce.Exception.OrderNotFoundException;
import com.ecommerce.Exception.ProductNotFoundException;
import com.ecommerce.Model.Address;
import com.ecommerce.Model.Order;
import com.ecommerce.Model.dto.OrderRequestDTO;
import com.ecommerce.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/order")
public class OrderController {
    @Autowired
    private OrderService orderService;

    @PostMapping("/create")
    public Order createOrder(@RequestBody OrderRequestDTO requestDTO) throws CustomerNotFoundException, ProductNotFoundException {
        Order created = orderService.createOrder(requestDTO);
        return created;
    }
    @DeleteMapping("/cancel")
    public void cancelOrder(@RequestParam Long orderId) throws OrderNotFoundException {
        orderService.cancelOrder(orderId);
    }


    @PutMapping("/updateshippingaddress")
    public void updateShippingAddress(@RequestParam Long orderId, @RequestBody Address address) throws OrderNotFoundException {
        orderService.updateShippingAddress(orderId,address);
    }

}
