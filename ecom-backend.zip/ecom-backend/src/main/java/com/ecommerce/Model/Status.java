package com.ecommerce.Model;

public enum Status {
    CREATED,
    PROCESSING,
    DELIVERED,
    SHIPPED,
    CANCELLED

}
